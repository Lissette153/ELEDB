from django.db import models
from django.contrib.auth.models import User
from django.utils.translation import gettext_lazy as _
from django.conf import settings
from django.contrib.auth.models import User



class Inventario(models.Model):
    """
    Modelo que representa el inventario de equipos.

    Atributos:
        nombre (str): Nombre del equipo.
        descripcion (str, optional): Descripción breve del equipo.
        tipo (str): Tipo de equipo con un choice (sonido, iluminación, accesorios, equipos_grabación, repuestos, montaje, transporte, produccion_eventos).
        cantidad (int): Cantidad disponible en el inventario.
        fecha_compra (date): Fecha de compra del equipo.
        monto_compra (Decimal): Monto pagado por la compra del equipo.
        estado_equipo (str): Estado actual del equipo.
    """
    TIPO_CHOICES = [
        ('default','Default'),
        ('sonido', 'Sonido'),
        ('iluminación','Iluminación'),
        ('accesorios', 'Accesorios'),
        ('equipos_grabación','Equipos de grabación'),
        ('repuestos', 'Repuestos'),
        ('montaje', 'Montaje'),
        ('transporte','Transporte'),
        ('producción_eventos','Producción de eventos'),
    ]

    ESTADO_CHOICES =[
        ('default','Default'),
        ('usado', 'Usado'),
        ('nuevo', 'Nuevo'),
        ('disponible', 'Disponible'),
        ('en_mantenimiento','En mantenimiento'),
        ('dañado', 'Dañado'),
        ('prestado', 'Prestado'),
    ]

    nombre = models.CharField(max_length=20)
    descripcion = models.CharField(max_length=100, blank=True, null=True)
    tipo = models.CharField(max_length=100, choices=TIPO_CHOICES)
    cantidad = models.IntegerField()
    fecha_compra = models.DateField()
    monto_compra = models.DecimalField(max_digits=10, decimal_places=2)
    estado_equipo = models.CharField(max_length=16, choices=ESTADO_CHOICES)
    
   
    class Meta:
        managed = False
        db_table = 'inventario'



class Finanzas(models.Model):
    """
    Modelo que representa las finanzas de la empresa.

    Atributos:
        nombre (str): Nombre de la transacción o categoría financiera.
        descripcion (str, optional): Descripción breve de la transacción.
        tipo (str): Tipo de transacción financiera (personal, ganancia, gasto, etc.).
        fecha (date): Fecha en que se realizó la transacción.
        monto_ganancia (int): Monto de la ganancia obtenida.
        estado_pago (str): Estado del pago (pagado, pendiente, vencido, etc.).
        costos (int): Costos asociados a la transacción.
        total (int): Total restante calculado automáticamente como la diferencia entre `monto_ganancia` y `costos`.

    Métodos:
        save(self, *args, **kwargs): 
            Sobrescribe el método `save` para calcular el `total` como 
            la diferencia entre `monto_ganancia` y `costos` antes de guardar el objeto.

    Meta:
        managed (bool): Indica si Django debe gestionar la tabla en la base de datos. Por defecto, está deshabilitado (`False`).
    """
    TIPO_CHOICES = [
        ('default', 'Default'),
        ("personal", "Personal"),
        ("ganancia", "Ganancia"),
        ("gasto", "Gasto"),
        ("publica", "Pública"),
        ("bancaria", "Bancaria"),
        ("proyectos", "Proyectos"),
    ]

    ESTADO_PAGO_CHOICES = [
        ('default', 'Default'),
        ("pagado", "Pagado"),
        ("no_pagado", "No Pagado"),
        ("pendiente", "Pendiente"),
        ("vencido", "Vencido"),
        ("reembolsado", "Reembolsado"),
    ]

    nombre = models.CharField(max_length=30)
    descripcion = models.CharField(max_length=50, blank=True, null=True)
    tipo = models.CharField(
        max_length=100, choices=TIPO_CHOICES, default="personal"
    )
    fecha = models.DateField()
    monto_ganancia = models.IntegerField()
    estado_pago = models.CharField(
        max_length=20, choices=ESTADO_PAGO_CHOICES, default="default"
    )
    costos = models.IntegerField()
    total = models.IntegerField(editable=False, default=0)

    def save(self, *args, **kwargs):
        self.total = self.monto_ganancia - self.costos
        super().save(*args, **kwargs)


    class Meta:
        managed = False
        db_table = 'finanzas'



class Eventos(models.Model):
    """
    Modelo que representa los eventos registrados.

    Atributos:
        nombre (str): Nombre del evento.
        descripcion (str, optional): Descripción breve del evento.
        fecha (date): Fecha en que se llevará a cabo el evento.
        monto (Decimal): Monto asociado al evento.
        cliente (str, optional): Nombre del cliente asociado al evento.
        direccion (str): Dirección donde se realizará el evento.
        equipos (str): Lista o descripción de los equipos utilizados en el evento.
        tipo (str): Tipo de evento.
        ficha_tecnica (File, optional): Archivo de ficha técnica relacionado con el evento.
        inventario (Foreign key): Relación entre inventario y eventos.
    """
    nombre = models.CharField(max_length=50)
    descripcion = models.CharField(max_length=100, blank=True, null=True)
    fecha = models.DateField()
    cliente = models.CharField(max_length=100, blank=True, null=True)
    direccion = models.CharField(max_length=50)
    equipos = models.CharField(max_length=100)
    tipo = models.CharField(max_length=100)
    ficha_tecnica = models.FileField(upload_to='fichas_tecnicas/', null=True, blank=True)
    inventario = models.ManyToManyField(Inventario)
    finanzas = models.ManyToManyField(Finanzas)  
    
    class Meta:
        managed = False
        db_table = 'eventos'






class PerfilUsuario(models.Model):
    """
    Modelo que representa el perfil de un usuario.

    Atributos:
        user (User): Usuario asociado al perfil.
        rol (str): Rol del usuario (Administrador, Gerente, Trabajador).
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    rol = [
        ('admin', 'Administrador'),
        ('gerente', 'Gerente'),
        ('trabajador', 'Trabajador'),
    ]
    rol = models.CharField(max_length=20, choices=rol)

    def __str__(self):
        """
        Representación en cadena del perfil de usuario.

        Returns:
            str: Email del usuario seguido de su rol.
        """
        return f"{self.user.email} ({self.get_rol_display()})"
