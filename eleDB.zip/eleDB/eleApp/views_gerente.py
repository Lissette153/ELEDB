from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test

from django.http import HttpRequest
from django.shortcuts import render

from .models import Eventos, Finanzas, Inventario
from django.contrib.auth.models import User
from django.contrib import messages
from datetime import datetime
import re




def es_superusuario(user):
    """
    Verifica si el usuario tiene el correo electrónico 'eleproducciones@gmail.com'.
    
    Args:
    user (User): El objeto de usuario que se va a verificar.

    Returns:
    bool: True si el usuario tiene este correo, False en caso contrario.
    """
    return  user.email == 'eleproducciones@gmail.com'



@login_required
@user_passes_test(es_superusuario)
def visualizar_evento_gerente(request: HttpRequest):
    """
    Vista para visualizar eventos registrados en la base de datos como usuario gerente.
    
    El evento se recupera de la base de datos y se muestra en una página de visualización.
    
    Args:
    request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    HttpResponse: La respuesta renderizada con el listado de eventos.
    """
    eventos = Eventos.objects.all()
    return render(request, 'gerente/evento/visualizar_evento_gerente.html', {
        'eventos': eventos,
    })


@login_required
@user_passes_test(es_superusuario)
def visualizar_finanza_gerente(request: HttpRequest):
    """
    Vista para visualizar finanzas registradas en la base de datos como usuario gerente.
    
   La finanza se recupera de la base de datos y se muestra en una página de visualización.
    
    Args:
    request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    HttpResponse: La respuesta renderizada con el listado de finanzas.
    """
    finanzas = Finanzas.objects.all()
    return render(request, 'gerente/finanza/ver_finanza.html', {
        'finanzas': finanzas,
    })

@login_required
@user_passes_test(es_superusuario)
def visualizar_inventario_gerente(request: HttpRequest):
    """
    Vista para visualizar el inventario registrado en la base de datos como usuario  gerente.
    
    El inventario se recupera de la base de datos y se muestra en una página de visualización.
    
    Args:
    request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    HttpResponse: La respuesta renderizada con el listado de inventario.
    """
    inventario = Inventario.objects.all()
    return render(request, 'gerente/inventario/ver_inventario.html', {
        'inventario': inventario,
    })


    """
    Vista para registrar un nuevo usuario tanto en la aplicación como en la base de datos a través de usuarios de django.
    
    El usuario se crea cuando se envian los datos mediante un formulario POST. Si los datos son válidos, 
    el usuario se guarda en la base de datos y se muestra un mensaje de éxito. Si hay errores, 
    se muestran los errores en el formulario.
    
    Método HTTP:
        POST: Si el método de la solicitud es 'POST', procesa los datos del formulario y crea un nuevo usuario.

    Args:
    request (HttpRequest): La solicitud HTTP recibida.
    is_superuser = 'superuser' in request.POST: Permite registrar en el sistema si es super usuario o no.
    user.is_staff: Permite registrar en el sistema si es staff. 
    'first_name': first_name: Permite registrar el nombre del usuario en el sistema de django. 
    'email': email: Permite registrar el correo del usuario en el sistema de django. 

    Returns:
    HttpResponse: La respuesta redirige hacia el formulario para registrar los datos del usuario ingresado y luego redigirira hacía a los datos registrados si se cumple la condición.
    """
    if request.method == 'POST':
        first_name = request.POST.get('first_name', '').strip()
        email = request.POST.get('email', '').strip()
        password = request.POST.get('password', '').strip()
        rol = request.POST.get('rol', '').strip()
        is_superuser = 'superuser' in request.POST

        errors = {}

        if not first_name:
            errors['first_name'] = 'El nombre es obligatorio.'
        elif len(first_name) < 5:
            errors['first_name'] = 'El nombre debe tener al menos 5 caracteres.'


        if not email:
            errors['email'] = 'El correo es obligatorio.'
        elif User.objects.filter(email=email).exists():
            errors['email'] = 'Este correo ya está registrado.'

        if not password:
            errors['password'] = 'La contraseña es obligatoria.'
        elif len(password) < 8:
            errors['password'] = 'La contraseña debe tener al menos 8 caracteres.'

  
        if not rol:
            errors['rol'] = 'El rol es obligatorio.'

        if errors:
            return render(request, 'gerente/user/registro_usuario.html', {
                'errors': errors,
                'first_name': first_name,
                'email': email,
                'rol': rol
            })


        user = User.objects.create_user(username=email, password=password, email=email)
        user.first_name = first_name

        if rol == 'administrador':
            user.is_staff = True  
        if is_superuser:
            user.is_superuser = True

        user.save()

        messages.success(request, 'Usuario creado exitosamente.')
        return redirect('/')

    return render(request, 'gerente/user/registro_usuario.html')

@login_required
@user_passes_test(es_superusuario)
def agregar_evento_gerente(request): 
    """
    Crea un nuevo evento.

    Esta vista permite la creación de un nuevo evento como gerente. Si la solicitud es de tipo 'POST' y los datos proporcionados son válidos,
    el evento se guarda en la base de datos. El formulario incluye campos para el nombre, descripción, fecha, finanzas asociadas, 
    cliente, dirección, inventario, tipo y ficha técnica.

    Si los datos son válidos, el evento se guarda y se redirige a la vista 'visualizar_evento' con un mensaje de éxito. 
    Si los datos son inválidos, el formulario se vuelve a renderizar mostrando los errores.

    Argumentos:
        request (HttpRequest): El objeto de solicitud HTTP que contiene los datos enviados desde el formulario.

    Variables de contexto disponibles en el formulario:
        - 'nombre': El nombre del evento.
        - 'descripcion': La descripción del evento.
        - 'fecha': La fecha del evento.
        - 'finanzas': Todos los objetos de Finanzas disponibles.
        - 'cliente': El nombre del cliente relacionado con el evento.
        - 'direccion': La dirección asociada con el evento.
        - 'inventario': Todos los objetos de Inventario disponibles.
        - 'tipo': El tipo del evento.
        - 'ficha_tecnica': El archivo de ficha técnica asociado al evento.
        - 'errors': Un diccionario con los errores de validación, si los hay.

    Retorna:
        HttpResponse: Si la solicitud es de tipo 'POST' y los datos son válidos, redirige a la vista 'visualizar_evento' 
        mostrando un mensaje de éxito. Si los datos no son válidos, el formulario se renderiza nuevamente con los errores.
        Si la solicitud es 'GET', se renderiza el formulario para crear un nuevo evento.

    Errores comunes:
        - Si algún campo obligatorio no se proporciona (nombre, cliente, tipo, dirección, fecha, ficha técnica), se mostrará
          un mensaje de error correspondiente.
        - Si el nombre, cliente o dirección exceden los límites de caracteres, se muestra un mensaje de error.
        - Si la fecha no tiene un formato válido o si los objetos de 'finanzas' o 'inventario' no existen, también se muestran
          mensajes de error.
    """
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        descripcion = request.POST.get('descripcion')
        fecha = request.POST.get('fecha')
        finanzas = request.POST.get('finanzas')
        cliente = request.POST.get('cliente')
        direccion = request.POST.get('direccion')
        inventario = request.POST.get('inventario')
        tipo = request.POST.get('tipo')
        ficha_tecnica = request.FILES.get('ficha_tecnica')  

        errors = {}

        if not nombre:
            errors['nombre'] = 'El campo "Nombre" es obligatorio.'
        elif len(nombre) > 50:
            errors['nombre'] = 'El campo "Nombre" no puede superar los 50 caracteres.'
        else:
            name_regex = r'^[a-zA-Z\s]+$' 
            if not re.match(name_regex, nombre):
                errors['nombre'] = 'El nombre solo debe contener letras.'



        if not cliente:
            errors['cliente'] = 'El campo "Cliente" es obligatorio.'
        elif len(cliente) > 50:
            errors['cliente'] = 'El campo "Cliente" no puede superar los 50 caracteres.'
  

        if inventario:
            try:
                inventario = Inventario.objects.get(id=inventario)
            except Inventario.DoesNotExist:
                errors['inventario'] = 'El inventario seleccionado no existe.'

        if finanzas:
            try:
                finanzas = Finanzas.objects.get(id=finanzas)
            except Finanzas.DoesNotExist:
                errors['finanzas'] = 'La finanza seleccionada no existe.'
                
    

        if not tipo:
            errors['tipo'] = 'El campo "Tipo" es obligatorio.'

        if not direccion:
            errors['direccion'] = 'El campo "Dirección" es obligatorio.'
        elif len(direccion) > 50:
            errors['direccion'] = 'El campo "Dirección" no puede superar los 50 caracteres.'
        

        if len(descripcion) > 100:
            errors['descripcion'] = 'El campo "Descripción" no puede superar los 100 caracteres.'
        else:
            name_regex = r'^[a-zA-Z\s]+$' 
            if not re.match(name_regex, direccion):
                errors['direccion'] = 'La dirección solo debe contener letras.'


        if not fecha:
            errors['fecha'] = 'La fecha es obligatoria.'
        else:
            try:
                fecha = datetime.strptime(fecha, '%Y-%m-%d').date()
            except ValueError:
                errors['fecha'] = 'La fecha no tiene un formato válido.'

        if not ficha_tecnica:
            errors['ficha_tecnica'] = 'La ficha tecnica es obligatoria.'


        if not errors:
            evento = Eventos(
                nombre=nombre,
                descripcion=descripcion,
                fecha=fecha,
                finanzas=finanzas,
                cliente=cliente,
                direccion=direccion,
                inventario=inventario,
                tipo=tipo,
                ficha_tecnica=ficha_tecnica,
            )
            evento.save()

            messages.success(request, 'Evento creado con éxito.')
            return redirect('visualizar_evento_gerente')  


        return render(request, 'gerente/evento/agregar_evento_gerente.html', {
            'errors': errors,
            'nombre': nombre,
            'descripcion': descripcion,
            'fecha': fecha,
            'finanzas': Finanzas.objects.all(),
            'cliente': cliente,
            'direccion': direccion,
            'inventario': Inventario.objects.all(),
            'tipo': tipo,
            'ficha_tecnica': ficha_tecnica,
        })

    return render(request, 'gerente/evento/agregar_evento_gerente.html', {
        'inventario': Inventario.objects.all(), 'finanzas': Finanzas.objects.all(),
    })


    """
    Vista para eliminar un usuario de la base de datos de auth_user según ID.
    
    El dato se elimina si la solicitud es un POST y el usuario confirma la eliminación.

    Método HTTP:
        POST: Si la solicitud es de tipo 'POST', se elimina el usuario correspondiente al `usuario_id`.
            Luego, se muestra un mensaje de éxito y se redirige a la página de visualización de usuarios.

    Args:
    request (HttpRequest): La solicitud HTTP recibida.
    usuario_id (int): El ID del usuario que se obtiene para eliminar.

    Returns:
    HttpResponse: La redirección a la página de visualización de los datos después de la eliminación.
    """
    usuario = get_object_or_404(User, id=usuario_id)
    if request.method == "POST":  
        usuario.delete()
        messages.success(request, f'¡Usuario eliminado con éxito!')
        return redirect('visualizar_usuarios')  

    return render(request, 'gerente/user/confirmar_eliminar.html', {'usuario': usuario})