from django.shortcuts import render

def index(request):
    return render(request, 'administrador/index.html')

def modificar_evento(request):
    return render(request, 'administrador/modificar_eventos.html')


def visualizar_evento(request):
    return render(request,'administrador/visualizar_evento.html' )

def modificar_finanza(request):
    return render(request, 'administrador/modificar_finanzas.html')
    