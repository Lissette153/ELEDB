from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test

from django.http import JsonResponse, HttpRequest
from django.shortcuts import render

from .models import Eventos, Finanzas, Inventario
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from datetime import datetime
from django.contrib import messages
import re
from django.contrib.auth.hashers import make_password



def es_trabajador(user):
    """
    Verifica si el usuario tiene el correo electrónico 'diego@gmail.com'.
    
    Args:
    user (User): El objeto de usuario que se va a verificar.

    Returns:
    bool: True si el usuario es un trabajador, False en caso contrario.
    """
    return user.email == 'diego@gmail.com'


def es_administrador_principal(user):
    """
    Verifica si el usuario es un administrador principal basado en si es superusuario
    y su correo electrónico es 'evelin73@gmail.com'.
    
    Args:
    user (User): El objeto de usuario que se va a verificar.

    Returns:
    bool: True si el usuario es el administrador principal, False en caso contrario.
    """
    return user.is_superuser and user.email == 'evelin73@gmail.com'


def index(request):
    """
    Vista principal de la página de inicio de sesión.
    
    Args:
    request (HttpRequest): La solicitud HTTP recibida.
    Returns:
    HttpResponse: La respuesta redirige al template de inicio.
    """
    return render(request, 'login/index_a.html')


def login_view(request):
    """
    Inicia sesión de un usuario en el sistema.

    Argumentos:
        request (HttpRequest): El objeto de solicitud HTTP que contiene la información de la petición, como los datos del formulario.

    Método HTTP:
        POST: Si la solicitud es de tipo 'POST', se obtienen las credenciales (nombre de usuario y contraseña) del formulario de inicio de sesión.
            Luego, se intenta autenticar al usuario utilizando esas credenciales. Si la autenticación es exitosa, se inicia sesión y se redirige al usuario a la página principal.
            Si la autenticación falla, se muestra un mensaje de error y el formulario de inicio de sesión se vuelve a renderizar.
        GET: Si la solicitud es de tipo 'GET', simplemente muestra el formulario de inicio de sesión.

    Retorna:
        HttpResponse: Si el inicio de sesión es exitoso, redirige a la página principal. Si la autenticación falla, muestra un mensaje de error en el formulario de inicio de sesión
    """
    if request.method == 'POST':
        username = request.POST.get('user')
        password = request.POST.get('pass')

        print(f"Datos recibidos: username={username}, password={password}")

        user = authenticate(request, username=username, password=password)
        if user is None:
            print("authenticate() devolvió None. Revisa el backend o los datos de usuario.")
        else:
            print(f"Usuario autenticado: {user}")

        if user is not None:
            login(request, user)
            messages.success(request, '¡Sesión iniciada con éxito!')
            return redirect('/')
        else:
            return render(request, 'login/login.html', {'error_message': 'Credenciales incorrectas'})
    return render(request, 'login/login.html') 


def logout_view(request):
    """
    Vista para cerrar la sesión del usuario.
    
    Al cerrar sesión, se muestra un mensaje de éxito y el usuario es redirigido a la página de inicio.
    
    Args:
    request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    HttpResponse: La redirección a la página de inicio de sesión con un mensaje de éxito.
    """
    logout(request)
    messages.success(request, f'¡Sesión cerrada con éxito!')
    return redirect('login')

## ------------------- ADMINISTRADORA -----------------------
@login_required
@user_passes_test(es_administrador_principal)
def agregar_evento(request): 
    """
    Vista para agregar un nuevo evento.

    Métodos:
    - POST:
    1. Recupera los datos enviados desde el formulario.
    2. Realiza validaciones para asegurar que los campos requeridos estén completos y en el formato correcto.
    3. Verifica la existencia de relaciones (finanzas e inventarios) en la base de datos.
    4. Si no hay errores:
        - Crea el evento en la base de datos.
        - Establece relaciones con las finanzas e inventarios seleccionados.
        - Redirige a la vista `visualizar_evento` con un mensaje de éxito.
    5. Si hay errores, renderiza nuevamente la plantilla con los errores y los datos ingresados.
    
    - GET:
    - Renderiza el formulario para agregar un evento vacío con las listas de finanzas e inventarios disponibles.

    Parámetros:
        - request (HttpRequest): La solicitud HTTP recibida desde el cliente.

    Retorno:
        - Para POST:
        - Redirige a `visualizar_evento` si los datos son válidos.
        - Renderiza `administrador/evento/agregar_evento.html` con errores y datos ingresados si hay errores.
        - Para GET:
        - Renderiza `administrador/evento/agregar_evento.html` con los datos iniciales del formulario.

    Plantilla utilizada:
        - `administrador/evento/agregar_evento.html`: Muestra el formulario para agregar un nuevo evento.
    """

    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        descripcion = request.POST.get('descripcion')
        fecha = request.POST.get('fecha')
        finanzas_seleccionadas = request.POST.getlist('finanzas')
        inventarios_seleccionados = request.POST.getlist('inventario')  
        cliente = request.POST.get('cliente')
        direccion = request.POST.get('direccion')
        tipo = request.POST.get('tipo')
        ficha_tecnica = request.FILES.get('ficha_tecnica')  

        errors = {}

        if not nombre:
            errors['nombre'] = 'El campo "Nombre" es obligatorio.'
        elif len(nombre) > 50:
            errors['nombre'] = 'El campo "Nombre" no puede superar los 50 caracteres.'
        

        if not cliente:
            errors['cliente'] = 'El campo "Cliente" es obligatorio.'
        elif len(cliente) > 50:
            errors['cliente'] = 'El campo "Cliente" no puede superar los 50 caracteres.'
  
        if finanzas_seleccionadas:
            finanzas_obj = []
            for finanza_id in finanzas_seleccionadas:
                try:
                    finanza = Finanzas.objects.get(id=finanza_id)
                    finanzas_obj.append(finanza)
                except Finanzas.DoesNotExist:
                    errors['finanzas'] = 'Una de las finanzas seleccionadas no existe.'
        else:
            errors['finanzas'] = 'Debe seleccionar al menos una finanza.'

        if inventarios_seleccionados:
            inventarios_obj = []
            for inventario_id in inventarios_seleccionados:
                try:
                    inventario = Inventario.objects.get(id=inventario_id)
                    inventarios_obj.append(inventario)
                except Inventario.DoesNotExist:
                    errors['inventario'] = 'Uno de los inventarios seleccionados no existe.'
        else:
            errors['inventario'] = 'Debe seleccionar al menos un inventario.'
        
        if not tipo:
            errors['tipo'] = 'El campo "Tipo" es obligatorio.'

        if not direccion:
            errors['direccion'] = 'El campo "Dirección" es obligatorio.'
        elif len(direccion) > 50:
            errors['direccion'] = 'El campo "Dirección" no puede superar los 50 caracteres.'
        
        if len(descripcion) > 100:
            errors['descripcion'] = 'El campo "Descripción" no puede superar los 100 caracteres.'
       

        if not fecha:
            errors['fecha'] = 'La fecha es obligatoria.'
        else:
            try:
                fecha = datetime.strptime(fecha, '%Y-%m-%d').date()
            except ValueError:
                errors['fecha'] = 'La fecha no tiene un formato válido.'

        if not ficha_tecnica:
            errors['ficha_tecnica'] = 'La ficha tecnica es obligatoria.'

        if not errors:
            evento = Eventos(
                nombre=nombre,
                descripcion=descripcion,
                fecha=fecha,
                cliente=cliente,
                direccion=direccion,
                tipo=tipo,
                ficha_tecnica=ficha_tecnica,
            )
            evento.save()

            evento.finanzas.set(finanzas_obj)
            evento.inventario.set(inventarios_obj)

            messages.success(request, 'Evento creado con éxito.')
            return redirect('visualizar_evento')  

        return render(request, 'administrador/evento/agregar_evento.html', {
            'errors': errors,
            'nombre': nombre,
            'descripcion': descripcion,
            'fecha': fecha,
            'finanzas': Finanzas.objects.all(),
            'cliente': cliente,
            'direccion': direccion,
            'inventario': Inventario.objects.all(),
            'tipo': tipo,
            'ficha_tecnica': ficha_tecnica,
        })

    return render(request, 'administrador/evento/agregar_evento.html', {
        'inventario': Inventario.objects.all(),
        'finanzas': Finanzas.objects.all(),
    })

@login_required
@user_passes_test(es_administrador_principal)
def visualizar_evento(request):
    """
    Vista para visualizar todos los eventos con sus detalles asociados.

    Este método consulta todos los eventos almacenados en la base de datos e incluye la información de las finanzas 
    y los inventarios relacionados con cada evento. La información se estructura y se envía a la plantilla para su visualización.

    Métodos:
    - GET:
    1. Recupera todos los eventos almacenados en la base de datos.
    2. Para cada evento:
        - Obtiene las finanzas relacionadas.
        - Obtiene los inventarios relacionados.
        - Organiza la información en un diccionario.
    3. Renderiza la plantilla con los eventos y sus datos relacionados.

    Parámetros:
        - request (HttpRequest): La solicitud HTTP recibida desde el cliente.

    Retorno:
        - Renderiza la plantilla 'administrador/evento/visualizar_evento.html' con una lista de eventos y sus detalles asociados.

    Plantilla utilizada:
        - 'administrador/evento/visualizar_evento.html': Muestra la lista de eventos con sus finanzas e inventarios relacionados.
    """

    eventos = Eventos.objects.all()
    
    eventos_con_datos = []
    

    for evento in eventos:
        finanzas_montos = evento.finanzas.all()  
        inventarios_nombres = evento.inventario.all()  
        
        eventos_con_datos.append({
            'evento': evento,
            'finanzas_montos': finanzas_montos,
            'inventarios_nombres': inventarios_nombres,
        })

    return render(request, 'administrador/evento/visualizar_evento.html', {
        'eventos_con_datos': eventos_con_datos,
    })


@login_required
@user_passes_test(es_administrador_principal)
def eliminar_evento(request, evento_id):
    """
    Vista para eliminar un evento de la base de datos.
    
    El evento se elimina si la solicitud es un POST y el usuario confirma la eliminación.
    
    Método HTTP:
        POST: Si la solicitud es de tipo 'POST', se elimina el evento correspondiente al `evento_id`.
            Luego, se muestra un mensaje de éxito y se redirige a la página de visualización de eventos.


    Args:
        request (HttpRequest): La solicitud HTTP recibida.
        evento_id (int): El ID del evento que se obtiene para eliminar.

    Returns:
    HttpResponse: La redirección a la página de visualización de eventos después de la eliminación.
    """
    eventos = get_object_or_404(Eventos, id=evento_id)
    if request.method == "POST":  
        eventos.delete()
        messages.success(request, f'¡Evento eliminado!')
        return redirect('visualizar_evento')  

    return render(request, 'administrador/evento/confirmar_eliminar.html', {'evento': eventos})

@login_required
@user_passes_test(es_administrador_principal)
def modificar_evento(request,evento_id ):
    """
    Modifica un evento existente según su ID.

    Esta vista permite la actualización de un evento. Si la solicitud es de tipo 'POST' y los datos enviados son válidos, 
    el evento se actualiza y se guarda en la base de datos. En el formulario, se pueden modificar el nombre, tipo, fecha, 
    finanzas asociadas, inventario y la ficha técnica del evento.

    Además, la vista permite acceder a los objetos relacionados de las tablas 'Finanzas' e 'Inventario', para asociarlos al evento.

    Argumentos:
        request (HttpRequest): El objeto de solicitud HTTP que contiene los datos enviados desde el formulario.
        evento_id (int): El ID del evento que se desea modificar.

    Variables de contexto disponibles en el formulario:
        - 'evento': El objeto del evento a modificar.
        - 'inventario': Todos los objetos del modelo Inventario disponibles.
        - 'finanzas': Todos los objetos del modelo Finanzas disponibles.
        - 'errors': Un diccionario con los errores de validación, si los hay.

    Retorna:
        HttpResponse: Si la solicitud es un 'POST' y los datos son válidos, redirige a la vista 'visualizar_evento' mostrando un 
        mensaje de éxito. Si los datos no son válidos, el formulario se renderiza nuevamente con los errores. 
        Si la solicitud es 'GET', muestra el formulario de modificación con los datos actuales del evento.

    Errores comunes:
        - Si no se proporciona un nombre válido, tipo, fecha o si los objetos de 'finanzas' e 'inventario' no existen, se 
          mostrará un mensaje de error correspondiente en el formulario.
    """
    evento = get_object_or_404(Eventos, pk=evento_id)
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        finanzas_ids = request.POST.getlist('finanzas')  
        tipo = request.POST.get('tipo')
        inventario_ids = request.POST.getlist('inventario') 
        fecha = request.POST.get('fecha')
        ficha_tecnica = request.FILES.get('ficha_tecnica')
        errors = {}

        if not nombre:
            errors['nombre'] = 'El nombre es obligatorio.'
        elif len(nombre) > 30:
            errors['nombre'] = 'El nombre no puede superar los 30 caracteres.'

        if not tipo:
            errors['tipo'] = 'El tipo de evento es obligatorio.'

   
        if not fecha:
            errors['fecha'] = 'La fecha es obligatoria.'
        else:
            try:
                fecha = datetime.strptime(fecha, '%Y-%m-%d').date()
            except ValueError:
                errors['fecha'] = 'La fecha no tiene un formato válido.'

   
        if finanzas_ids:
            finanzas = Finanzas.objects.filter(id__in=finanzas_ids)
            if not finanzas.exists():
                errors['finanzas'] = 'Algunas finanzas seleccionadas no existen.'
        else:
            finanzas = []


        if inventario_ids:
            inventario = Inventario.objects.filter(id__in=inventario_ids)
            if not inventario.exists():
                errors['inventario'] = 'Algunos inventarios seleccionados no existen.'
        else:
            inventario = []


        if not errors:
            evento.nombre = nombre
            evento.tipo = tipo
            evento.fecha = fecha


            evento.finanzas.set(finanzas)  
            evento.inventario.set(inventario)  


            if ficha_tecnica:
                evento.ficha_tecnica = ficha_tecnica

            evento.save()

            messages.success(request, 'Evento actualizado con éxito.')
            return redirect('visualizar_evento') 


        return render(request, 'administrador/evento/modificar_eventos.html', {
            'errors': errors,
            'evento': evento,
            'inventario': Inventario.objects.all(),
            'finanzas': Finanzas.objects.all(),
        })


    return render(request, 'administrador/evento/modificar_eventos.html', {
        'evento': evento,
        'inventario': Inventario.objects.all(),
        'finanzas': Finanzas.objects.all(),
    })

#####---------------------------------FINANZAAAAA---------------------------------------------#####

@login_required
@user_passes_test(es_administrador_principal)
def modificar_finanzas(request, finanza_id):
    """
    Modifica una finanza existente.

    Esta vista permite la modificación de una finanza ya existente en la base de datos. Si la solicitud es de tipo 'POST' y los datos proporcionados son válidos,
    la finanza se actualiza con los nuevos valores. Si los datos son válidos, se guarda la finanza actualizada y se redirige a la vista 'visualizar_finanza' con un mensaje de éxito. 
    Si los datos son inválidos, el formulario se vuelve a renderizar mostrando los errores.

    Argumentos:
        request (HttpRequest): El objeto de solicitud HTTP que contiene los datos enviados desde el formulario.
        finanza_id (int): El ID de la finanza que se desea modificar.

    Variables de contexto disponibles en el formulario:
        - 'nombre': El nombre de la finanza.
        - 'tipo': El tipo de finanza.
        - 'fecha': La fecha de la finanza.
        - 'monto_ganancia': El monto de ganancia asociado a la finanza.
        - 'estado_pago': El estado del pago (si está pagado o pendiente).
        - 'costos': El costo asociado a la finanza.
        - 'errors': Un diccionario con los errores de validación, si los hay.
        - 'finanza': El objeto de finanza que se está editando.

    Retorna:
        HttpResponse: Si la solicitud es de tipo 'POST' y los datos son válidos, redirige a la vista 'visualizar_finanza' con un mensaje de éxito.
        Si los datos no son válidos, el formulario se renderiza nuevamente con los errores.
        Si la solicitud es 'GET', se renderiza el formulario con los datos actuales de la finanza.

    Errores comunes:
        - Si algún campo obligatorio no se proporciona (nombre, tipo, fecha, estado_pago, costos), se mostrará un mensaje de error correspondiente.
        - Si los campos `monto_ganancia` o `costos` no son números válidos, se muestra un mensaje de error.
        - Si la fecha no tiene un formato válido (no es `YYYY-MM-DD`), se muestra un mensaje de error.
    """
    finanza = get_object_or_404(Finanzas, pk=finanza_id)
    
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        tipo = request.POST.get('tipo')
        fecha = request.POST.get('fecha')
        monto_ganancia = request.POST.get('monto_ganancia')
        estado_pago = request.POST.get('estado_pago')
        costos = request.POST.get('costos')

        errors = {}


        if not nombre:
            errors['nombre'] = 'El nombre es obligatorio.'
        elif len(nombre) > 30:
            errors['nombre'] = 'El nombre no puede superar los 30 caracteres.'


        if not tipo:
            errors['tipo'] = 'El tipo de finanza es obligatorio.'

        if not fecha:
            errors['fecha'] = 'La fecha es obligatoria.'
        else:
            try:
                fecha = datetime.strptime(fecha, '%Y-%m-%d').date()
            except ValueError:
                errors['fecha'] = 'La fecha no tiene un formato válido.'


        try:
            monto_ganancia = int(monto_ganancia)
        except (ValueError, TypeError):
            errors['monto_ganancia'] = 'Por favor, ingrese un número válido y/o solo números.'

        if not estado_pago:
            errors['estado_pago'] = 'El estado de pago es obligatorio.'

        if not costos:
            errors['costos'] = 'El costo es obligatorio.'

        try:
            costos = int(costos)
        except (ValueError, TypeError):
            errors['costos'] = 'Por favor, ingrese un número válido y/o solo números.'

        if not errors:
            finanza.nombre = nombre
            finanza.tipo = tipo
            finanza.fecha = fecha
            finanza.monto_ganancia = monto_ganancia
            finanza.estado_pago = estado_pago
            finanza.costos = costos
            finanza.save()

            messages.success(request, 'Finanza actualizada exitosamente.')
            return redirect('visualizar_finanza')  

        return render(request, 'administrador/finanza/modificar_finanzas.html', {
            'errors': errors,
            'finanza': finanza,
        })


    return render(request, 'administrador/finanza/modificar_finanzas.html', {
        'finanza': finanza,
    })


@login_required
@user_passes_test(es_administrador_principal)
def visualizar_finanza(request: HttpRequest):
    """
    Vista para visualizar todos los datos almacenados en la base de datos.
    
    La finanza se recupera de la base de datos y se muestra en una página de visualización.
    
    Args:
    request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    HttpResponse: La respuesta renderizada con el listado de finanza
    """
    finanzas = Finanzas.objects.all()
    return render(request, 'administrador/finanza/ver_finanza.html', {'finanzas': finanzas} )

@login_required
@user_passes_test(es_administrador_principal)
def eliminar_finanzas(request, finanza_id):
    """
    Vista para eliminar una finanza de la base de datos según ID.
    
    La finanza se elimina si la solicitud es un POST y el usuario confirma la eliminación.
    
      
    Método HTTP:
        POST: Si la solicitud es de tipo 'POST', se elimina la finanza correspondiente al 'finanza_id`.
            Luego, se muestra un mensaje de éxito y se redirige a la página de visualización de finanzas.


    Args:
    request (HttpRequest): La solicitud HTTP recibida.
    finanza_id (int): El ID de la finanza que se obtiene para eliminar.

    Returns:
    HttpResponse: La redirección a la página de visualización de la finanza después de la eliminación.
    """
    finanza = get_object_or_404(Finanzas, id=finanza_id)
    if request.method == "POST":  
        finanza.delete()
        messages.success(request, f'¡Finanza eliminada con éxito!')
        return redirect('visualizar_finanza')  

    return render(request, 'administrador/finanza/confirmar_eliminar.html', {'finanza': finanza})


@login_required
@user_passes_test(es_administrador_principal)
def registrar_finanza(request):
    """
    Crea una nueva finanza.

    Esta vista permite crear una nueva finanza mediante un formulario. Si la solicitud es de tipo 'POST' y los datos proporcionados son válidos, 
    la nueva finanza se guarda en la base de datos y se redirige a la vista 'visualizar_finanza' con un mensaje de éxito. 
    Si los datos son inválidos, el formulario se vuelve a renderizar mostrando los errores de validación.

    Argumentos:
        request (HttpRequest): El objeto de solicitud HTTP que contiene los datos enviados desde el formulario.

    Variables de contexto disponibles en el formulario:
        - 'nombre': El nombre de la finanza.
        - 'descripcion': La descripción de la finanza.
        - 'tipo': El tipo de finanza.
        - 'fecha': La fecha de la finanza.
        - 'monto_ganancia': El monto de ganancia asociado a la finanza.
        - 'estado_pago': El estado del pago (si está pagado o pendiente).
        - 'costos': El costo asociado a la finanza.
        - 'errors': Un diccionario con los errores de validación, si los hay.

    Retorna:
        HttpResponse: Si la solicitud es de tipo 'POST' y los datos son válidos, redirige a la vista 'visualizar_finanza' con un mensaje de éxito.
        Si los datos no son válidos, el formulario se renderiza nuevamente con los errores.
        Si la solicitud es 'GET', se renderiza el formulario vacío para ingresar los datos.

    Errores comunes:
        - Si el nombre es vacío o supera los 30 caracteres, se mostrará un mensaje de error.
        - Si la descripción supera los 50 caracteres, se muestra un error.
        - Si el tipo de finanza, la fecha, el estado de pago o los costos están vacíos, se muestran mensajes de error.
        - Si el monto de ganancia o los costos no son números válidos, se muestra un mensaje de error.
        - Si la fecha no tiene un formato válido (no es `YYYY-MM-DD`), se muestra un mensaje de error.
    """
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        descripcion = request.POST.get('descripcion')
        tipo = request.POST.get('tipo')
        fecha = request.POST.get('fecha')
        monto_ganancia = request.POST.get('monto_ganancia')
        estado_pago = request.POST.get('estado_pago')
        costos = request.POST.get('costos')

        errors = {}

        if not nombre:
            errors['nombre'] = 'El nombre es obligatorio.'
        elif len(nombre) > 30:
            errors['nombre'] = 'El nombre no puede superar los 30 caracteres.'

        if len(descripcion) > 50:
            errors['nombre'] = 'La descripción no puede superar los 50 caracteres'


        if not tipo:
            errors['tipo'] = 'El tipo de finanza es obligatorio.'

        if not fecha:
            errors['fecha'] = 'La fecha es obligatoria.'

        if not costos:
            errors['costos'] = 'El costo es obligatorio.'

        else:
            try:
                fecha = datetime.strptime(fecha, '%Y-%m-%d').date()
            except ValueError:
                errors['fecha'] = 'La fecha no tiene un formato válido.'


        if not monto_ganancia:
            errors['monto_ganancia'] = 'El monto de ganancias es obligatorio.'
        elif not monto_ganancia.isdigit():
            messages.error(request, 'Por favor, ingrese solo números.')

        if not estado_pago:
            errors['estado_pago'] = 'El estado de pago es obligatorio.'
        
        if not costos:
            errors['costos'] = 'El monto de costos/gastos es obligatorio.'
        elif not costos.isdigit():
            messages.error(request, 'Por favor, ingrese solo números.')

        if not errors:
            finanzas = Finanzas(
                nombre=nombre,
                descripcion = descripcion,
                fecha=fecha,
                tipo=tipo,
                monto_ganancia=int(monto_ganancia),
                estado_pago=estado_pago,
                costos=int(costos),
            )
            finanzas.save()
            messages.success(request, 'Finanza creada exitosamente.')
            return redirect('visualizar_finanza')  

       
        return render(request, 'administrador/finanza/registro_finanza.html', {
            'errors': errors,
            'nombre': nombre,
            'tipo': tipo,
            'fecha': fecha,
            'monto_ganancia': monto_ganancia,
            'estado_pago': estado_pago,
            'costos': costos
        })

    return render(request, 'administrador/finanza/registro_finanza.html')


##############################################################################

def calendario(request):
    return render(request, 'administrador/visualizar_calendario.html')


def obtener_eventos_mes(request):
    year = int(request.GET.get('year', datetime.now().year))
    month = int(request.GET.get('month', datetime.now().month))

    eventos = Eventos.objects.filter(fecha__year=year, fecha__month=month)
    eventos_data = []

    for evento in eventos:
        eventos_data.append({
            'id': evento.id,
            'nombre': evento.nombre,
            'descripcion': evento.descripcion,
            'fecha': evento.fecha.strftime('%Y-%m-%d'),
            'monto': float(evento.monto),
            'cliente': evento.cliente,
            'direccion': evento.direccion,
            'equipos': evento.equipos,
            'tipo': evento.tipo,
        })

    return JsonResponse({'eventos': eventos_data})


    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        descripcion = request.POST.get('descripcion')
        tipo = request.POST.get('tipo')
        fecha = request.POST.get('fecha')
        monto_ganancia = request.POST.get('monto_ganancia')
        estado_pago = request.POST.get('estado_pago')
        costos = request.POST.get('costos')

        errors = {}

        if not nombre:
            errors['nombre'] = 'El nombre es obligatorio.'
        elif len(nombre) > 30:
            errors['nombre'] = 'El nombre no puede superar los 30 caracteres.'
        else:
            name_regex = r'^[a-zA-Z\s]+$' 
            if not re.match(name_regex, nombre):
                errors['nombre'] = 'El nombre solo debe contener letras.'

        if len(descripcion) > 50:
            errors['nombre'] = 'La descripción no puede superar los 50 caracteres'
        else:
            name_regex = r'^[a-zA-Z\s]+$' 
            if not re.match(name_regex, nombre):
                errors['nombre'] = 'El nombre solo debe contener letras.'


        if not tipo:
            errors['tipo'] = 'El tipo de finanza es obligatorio.'

        if not fecha:
            errors['fecha'] = 'La fecha es obligatoria.'
        else:
            try:
                fecha = datetime.strptime(fecha, '%Y-%m-%d').date()
            except ValueError:
                errors['fecha'] = 'La fecha no tiene un formato válido.'


        if not monto_ganancia:
            errors['monto_ganancia'] = 'El monto de ganancias es obligatorio.'
        elif not monto_ganancia.isdigit():
            messages.error(request, 'Por favor, ingrese solo números.')

        if not estado_pago:
            errors['estado_pago'] = 'El estado de pago es obligatorio.'
        
        if not costos:
            errors['costos'] = 'El monto de costos/gastos es obligatorio.'
        elif not costos.isdigit():
            messages.error(request, 'Por favor, ingrese solo números.')

        if not errors:
            finanzas = Finanzas(
                nombre=nombre,
                descripcion = descripcion,
                fecha=fecha,
                tipo=tipo,
                monto_ganancia=int(monto_ganancia),
                estado_pago=estado_pago,
                costos=int(costos),
            )
            finanzas.save()
            messages.success(request, 'Finanza creada exitosamente.')
            return redirect('visualizar_finanza')  

       
        return render(request, 'administrador/finanza/registro_finanza.html', {
            'errors': errors,
            'nombre': nombre,
            'tipo': tipo,
            'fecha': fecha,
            'monto_ganancia': monto_ganancia,
            'estado_pago': estado_pago,
            'costos': costos
        })

    return render(request, 'administrador/finanza/registro_finanza.html')

@login_required
@user_passes_test(es_administrador_principal)
def visualizar_inventario(request: HttpRequest):
    """
    Vista para visualizar todo el inventario almacenado en la base de datos.
    
    El inventario se recupera de la base de datos y se muestra en una página de visualización.
    
    Args:
    request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    HttpResponse: La respuesta renderizada con el listado de datos.
    """
    inventario = Inventario.objects.all()
    return render(request, 'administrador/inventario/ver_inventario.html', {'inventario': inventario} )


@login_required
@user_passes_test(es_administrador_principal)
def registro_inventario(request):
    """
    Registra un nuevo equipo en el inventario.

    Esta vista permite registrar un nuevo equipo en el inventario mediante un formulario. Si la solicitud es de tipo 'POST' y los datos 
    proporcionados son válidos, el equipo se guarda en la base de datos y se redirige a la vista 'visualizar_inventario' con un mensaje de éxito. 
    Si los datos son inválidos, el formulario se vuelve a renderizar mostrando los errores de validación.

    Argumentos:
        request (HttpRequest): El objeto de solicitud HTTP que contiene los datos enviados desde el formulario.

    Variables de contexto disponibles en el formulario:
        - 'nombre': El nombre del equipo.
        - 'descripcion': La descripción del equipo.
        - 'tipo': El tipo de equipo.
        - 'cantidad': La cantidad de unidades del equipo.
        - 'fecha_compra': La fecha de compra del equipo.
        - 'monto_compra': El monto de compra del equipo.
        - 'estado_equipo': El estado actual del equipo (nuevo, usado, etc.).
        - 'errors': Un diccionario con los errores de validación, si los hay.

    Retorna:
        HttpResponse: Si la solicitud es de tipo 'POST' y los datos son válidos, redirige a la vista 'visualizar_inventario' con un mensaje de éxito.
        Si los datos no son válidos, el formulario se renderiza nuevamente con los errores.
        Si la solicitud es 'GET', se renderiza el formulario vacío para ingresar los datos.

    Errores comunes:
        - Si el nombre es vacío o supera los 20 caracteres, se muestra un mensaje de error.
        - Si la descripción supera los 100 caracteres, se muestra un mensaje de error.
        - Si el tipo de equipo está vacío, se muestra un mensaje de error.
        - Si la fecha de compra no tiene un formato válido (no es `YYYY-MM-DD`), se muestra un mensaje de error.
        - Si el monto de compra no es un número válido, se muestra un mensaje de error.
        - Si la cantidad no es un número válido o está vacío, se muestra un mensaje de error.
        - Si el estado del equipo está vacío, se muestra un mensaje de error.
    """
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        descripcion = request.POST.get('descripcion')
        tipo = request.POST.get('tipo')
        cantidad = request.POST.get('cantidad')
        fecha_compra = request.POST.get('fecha_compra')
        monto_compra = request.POST.get('monto_compra')
        estado_equipo = request.POST.get('estado_equipo')

        errors = {}

        if not nombre:
            errors['nombre'] = 'El nombre es obligatorio.'
        elif len(nombre) > 20:
            errors['nombre'] = 'El nombre no puede superar los 20 caracteres.'


        if len(descripcion) > 100:
            errors['nombre'] = 'La descripción debe tener un máximo de 100 caracteres.'
       

        if not tipo:
            errors['tipo'] = 'El tipo de equipo es obligatorio.'

        if not fecha_compra:
            errors['fecha_compra'] = 'La fecha es obligatoria.'
        else:
            try:
                fecha_compra = datetime.strptime(fecha_compra, '%Y-%m-%d').date()
            except ValueError:
                errors['fecha_compra'] = 'La fecha no tiene un formato válido.'

        if not monto_compra:
            errors['monto_ganancia'] = 'El monto de compra es obligatorio.'
        elif not monto_compra.isdigit():
            messages.error(request, 'Por favor, ingrese solo números.')

        
        if not cantidad:
            errors['cantidad'] = 'La cantidad es obligatoria.'
        elif not cantidad.isdigit():
            messages.error(request, 'Por favor, ingrese solo números.')


        if not estado_equipo:
            errors['estado_pago'] = 'El estado del equipo es obligatorio.'
        

        if not errors:
            inventario = Inventario(
                nombre=nombre,
                descripcion = descripcion,
                tipo=tipo,
                cantidad=int(cantidad),
                fecha_compra=fecha_compra,
                monto_compra=int(monto_compra),
                estado_equipo=estado_equipo,
            )
            inventario.save()
            messages.success(request, 'Equipo registrado exitosamente.')
            return redirect('visualizar_inventario')  

       
        return render(request, 'administrador/inventario/registro_inventario.html', {
            'errors': errors,
            'nombre': nombre,
            'tipo': tipo,
            'cantidad':int(cantidad),
            'fecha_compra': fecha_compra,
            'monto_compra': int(monto_compra),
            'estado_equipo': estado_equipo,
        })

    return render(request, 'administrador/inventario/registro_inventario.html')


@login_required
@user_passes_test(es_administrador_principal)
def eliminar_inventario(request, inventario_id):
    """
    Vista para eliminar un equipo de la base de datos de inventario según ID.
    
    El dato se elimina si la solicitud es un POST y el usuario confirma la eliminación.

       
    Método HTTP:
        POST: Si la solicitud es de tipo 'POST', se elimina el inventario correspondiente al 'inventario_id`.
            Luego, se muestra un mensaje de éxito y se redirige a la página de visualización de inventario.

    
    Args:
    request (HttpRequest): La solicitud HTTP recibida.
    inventario_id (int): El ID del inventario que se obtiene para eliminar.

    Returns:
    HttpResponse: La redirección a la página de visualización de los datos después de la eliminación.
    """
    inventario = get_object_or_404(Inventario, id=inventario_id)
    if request.method == "POST":  
        inventario.delete()
        messages.success(request, f'¡Inventario eliminado con éxito!')
        return redirect('visualizar_inventario')  

    return render(request, 'administrador/inventario/confirmar_eliminar.html', {'inventario': inventario})


@login_required
@user_passes_test(es_administrador_principal)
def modificar_inventario(request, inventario_id):
    """
    Vista para modificar un inventario existente. 

    Esta vista permite actualizar los detalles de un equipo en el inventario, incluyendo su nombre, fecha de compra, monto de compra y estado. Los datos son validados antes de realizar la actualización. Si hay errores de validación, se muestran en la misma página, permitiendo al usuario corregirlos.

    Parámetros:
    - `inventario_id`: ID del inventario que se va a modificar (recuperado mediante `get_object_or_404`).

    Métodos:
    - `POST`: Recibe los datos del formulario para modificar el inventario. Realiza las validaciones necesarias y, si no hay errores, guarda los cambios en el objeto `Inventario`.
    - `GET`: Muestra el formulario con los datos actuales del inventario.

    Errores:
    - Si los datos ingresados no son válidos, se muestran mensajes de error detallados.
    - Los campos requeridos son `nombre`, `fecha_compra`, `monto_compra`, y `estado_equipo`.

    Redirección:
    - Si los datos se actualizan correctamente, el usuario es redirigido a la vista que muestra el inventario actualizado (`visualizar_inventario`).

    Plantillas:
    - `administrador/inventario/modificar_inventario.html`: Se utiliza para mostrar el formulario de modificación de inventario.

    Ejemplo de errores:
    - 'El nombre es obligatorio.'
    - 'La fecha no tiene un formato válido.'
    - 'Por favor, ingrese un número válido para el monto de compra.'
    """

    inventario = get_object_or_404(Inventario, pk=inventario_id)
    
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        fecha_compra = request.POST.get('fecha_compra')
        monto_compra = request.POST.get('monto_compra')
        estado_equipo = request.POST.get('estado_equipo')

        errors = {}

        if not nombre:
            errors['nombre'] = 'El nombre es obligatorio.'
        elif len(nombre) > 20:
            errors['nombre'] = 'El nombre no puede superar los 20 caracteres.'


        if not fecha_compra:
            errors['fecha_compra'] = 'La fecha es obligatoria.'
        else:
            try:
                fecha_compra = datetime.strptime(fecha_compra, '%Y-%m-%d').date()
            except ValueError:
                errors['fecha_compra'] = 'La fecha no tiene un formato válido.'


        try:
            monto_compra = int(monto_compra)
        except (ValueError, TypeError):
            errors['monto_compra'] = 'Por favor, ingrese un número válido.'


        if not estado_equipo:
            errors['estado_equipo'] = 'El estado del equipo es obligatorio.'

        if not errors:
            inventario.nombre = nombre
            inventario.fecha_compra = fecha_compra
            inventario.monto_compra = monto_compra
            inventario.estado_equipo = estado_equipo
            inventario.save()

            messages.success(request, 'Inventario actualizado exitosamente.')
            return redirect('visualizar_inventario')  


        return render(request, 'administrador/inventario/modificar_inventario.html', {
            'errors': errors,
            'inventario': inventario,
        })

    return render(request, 'administrador/inventario/modificar_inventario.html', {
        'inventario': inventario,
    })


@login_required
@user_passes_test(es_administrador_principal)
def visualizar_usuarios(request):
    """
    Vista para visualizar usuarios registrados en la base de datos.
    
    El usuario se recupera de la base de datos y se muestra en una página de visualización.
    
    Args:
    request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    HttpResponse: La respuesta renderizada con el listado de usuarios.
    """
    users = User.objects.all()
    return render(request, 'gerente/user/visualizar_usuarios.html', {'users': users})



@login_required
@user_passes_test(es_administrador_principal)
def crear_usuarios(request):
    """
    Vista para registrar un nuevo usuario tanto en la aplicación como en la base de datos a través de usuarios de django.
    
    El usuario se crea cuando se envian los datos mediante un formulario POST. Si los datos son válidos, 
    el usuario se guarda en la base de datos y se muestra un mensaje de éxito. Si hay errores, 
    se muestran los errores en el formulario.
    
    Método HTTP:
        POST: Si el método de la solicitud es 'POST', procesa los datos del formulario y crea un nuevo usuario.

    Args:
    request (HttpRequest): La solicitud HTTP recibida.
    is_superuser = 'superuser' in request.POST: Permite registrar en el sistema si es super usuario o no.
    user.is_staff: Permite registrar en el sistema si es staff. 
    'first_name': first_name: Permite registrar el nombre del usuario en el sistema de django. 
    'email': email: Permite registrar el correo del usuario en el sistema de django. 

    Returns:
    HttpResponse: La respuesta redirige hacia el formulario para registrar los datos del usuario ingresado y luego redigirira hacía a los datos registrados si se cumple la condición.
    """
    if request.method == 'POST':
        first_name = request.POST.get('first_name', '').strip()
        email = request.POST.get('email', '').strip()
        password = request.POST.get('password', '').strip()
        rol = request.POST.get('rol', '').strip()
        is_superuser = 'superuser' in request.POST

        errors = {}

        if not first_name:
            errors['first_name'] = 'El nombre es obligatorio.'
        elif len(first_name) < 5:
            errors['first_name'] = 'El nombre debe tener al menos 5 caracteres.'


        if not email:
            errors['email'] = 'El correo es obligatorio.'
        elif User.objects.filter(email=email).exists():
            errors['email'] = 'Este correo ya está registrado.'

        if not password:
            errors['password'] = 'La contraseña es obligatoria.'
        elif len(password) < 8:
            errors['password'] = 'La contraseña debe tener al menos 8 caracteres.'

  
        if not rol:
            errors['rol'] = 'El rol es obligatorio.'

        if errors:
            return render(request, 'gerente/user/registro_usuario.html', {
                'errors': errors,
                'first_name': first_name,
                'email': email,
                'rol': rol
            })


        user = User.objects.create_user(username=email, password=password, email=email)
        user.first_name = first_name

        if rol == 'administrador':
            user.is_staff = True  
        if is_superuser:
            user.is_superuser = True

        user.save()

        messages.success(request, 'Usuario creado exitosamente.')
        return redirect('/')

    return render(request, 'gerente/user/registro_usuario.html')


@login_required
@user_passes_test(es_administrador_principal)
def eliminar_usuario(request, usuario_id):
    """
    Vista para eliminar un usuario de la base de datos de auth_user según ID.
    
    El dato se elimina si la solicitud es un POST y el usuario confirma la eliminación.

    Método HTTP:
        POST: Si la solicitud es de tipo 'POST', se elimina el usuario correspondiente al `usuario_id`.
            Luego, se muestra un mensaje de éxito y se redirige a la página de visualización de usuarios.

    Args:
    request (HttpRequest): La solicitud HTTP recibida.
    usuario_id (int): El ID del usuario que se obtiene para eliminar.

    Returns:
    HttpResponse: La redirección a la página de visualización de los datos después de la eliminación.
    """
    usuario = get_object_or_404(User, id=usuario_id)
    if request.method == "POST":  
        usuario.delete()
        messages.success(request, f'¡Usuario eliminado con éxito!')
        return redirect('visualizar_usuarios')  

    return render(request, 'gerente/user/confirmar_eliminar.html', {'usuario': usuario})



## ------------------- TRABAJADOR -----------------------
@login_required
@user_passes_test(es_trabajador)
def visualizar_evento_trabajador(request: HttpRequest):
    """
    Vista para visualizar eventos registrados en la base de datos como usuario trabajador.
    
    El evento se recupera de la base de datos y se muestra en una página de visualización.
    
    Args:
    request (HttpRequest): La solicitud HTTP recibida.

    Returns:
    HttpResponse: La respuesta renderizada con el listado de eventos.
    """
    eventos = Eventos.objects.all()
    return render(request, 'trabajador/visualizar_evento_trabajador.html', {
        'eventos': eventos,
    })
