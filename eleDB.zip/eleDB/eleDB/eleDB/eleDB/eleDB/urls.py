

from django.contrib import admin
from django.urls import path
from eleApp import views, views_gerente
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index),
    path('admin/', admin.site.urls),
    path('logout', views.logout_view, name='logout'),

    ##---_ADMINISTRADORA_-----------------
    path('visualizar_evento/', views.visualizar_evento, name='visualizar_evento'),
    path('agregar_evento', views.agregar_evento, name='agregar_evento'),

    path('login', views.login_view, name='login'),

    path('modificar_evento/<int:evento_id>', views.modificar_evento,  name='modificar_evento'),
    path('api/obtener-eventos-mes/', views.obtener_eventos_mes, name='obtener_eventos_mes'),
    path('calendario', views.calendario, name='calendario'),
    path('eliminar_evento/<int:evento_id>/', views.eliminar_evento, name='eliminar_evento'),

    path('registrar_finanza', views.registrar_finanza, name='registrar_finanza'),
    path('visualizar_finanza/', views.visualizar_finanza, name='visualizar_finanza'),
    path('eliminar_finanzas/<int:finanza_id>/', views.eliminar_finanzas, name='eliminar_finanzas'),
    path('modificar_finanzas/<int:finanza_id>/', views.modificar_finanzas, name='modificar_finanzas'),


    path('visualizar_inventario', views.visualizar_inventario, name='visualizar_inventario'),
    path('registro_inventario', views.registro_inventario, name='registro_inventario'),    
    path('modificar_inventario/<int:inventario_id>', views.modificar_inventario, name='modificar_inventario'),  
    path('eliminar_inventario/<int:inventario_id>/', views.eliminar_inventario, name='eliminar_inventario'),

    ##------_GERENTE_--------------------------------------------------------------------------------
    path('visualizar_evento_gerente', views_gerente.visualizar_evento_gerente, name='visualizar_evento_gerente'),
    path('visualizar_usuarios/', views.visualizar_usuarios, name='visualizar_usuarios'),
    path('visualizar_finanza_gerente', views_gerente.visualizar_finanza_gerente, name='visualizar_finanza_gerente'),
    path('visualizar_inventario_gerente', views_gerente.visualizar_inventario_gerente, name='visualizar_inventario_gerente'),
    path('crear_usuario/', views.crear_usuarios, name='crear_usuario'),
    path('eliminar_usuario/<int:usuario_id>/', views.eliminar_usuario, name='eliminar_usuario'),
    path('agregar_evento_gerente/',views_gerente.agregar_evento_gerente, name='agregar_evento_gerente'),

    ##-----_TRABAJADOR_---------------------------------------------------------------------------------------------
    path('visualizar_evento_trabajador', views.visualizar_evento_trabajador, name='visualizar_evento_trabajador'), 
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)