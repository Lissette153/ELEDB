const calendar = document.getElementById('calendar');
const monthYear = document.getElementById('monthYear');
const currentDate = new Date();
let currentYear = currentDate.getFullYear();
let currentMonth = currentDate.getMonth();

async function fetchEventos(year, month) {
    const response = await fetch(`/api/obtener-eventos-mes/?year=${year}&month=${month + 1}`);
    const data = await response.json();
    return data.eventos;
}

async function renderCalendar() {
    calendar.innerHTML = '';
    const year = currentYear;
    const month = currentMonth;

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    monthYear.innerText = `${currentDate.toLocaleString('default', { month: 'long' })} ${year}`;

    const eventos = await fetchEventos(year, month);
    const eventosPorDia = {};

    eventos.forEach(evento => {
        const dia = parseInt(evento.fecha.split('-')[2]);
        if (!eventosPorDia[dia]) {
            eventosPorDia[dia] = [];
        }
        eventosPorDia[dia].push(evento);
    });

    for (let i = 0; i < firstDay; i++) {
        calendar.appendChild(document.createElement('div'));
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const dayCell = document.createElement('div');
        dayCell.className = 'day';
        dayCell.innerText = day;

        if (eventosPorDia[day]) {
            eventosPorDia[day].forEach(evento => {
                const eventDiv = document.createElement('div');
                eventDiv.className = 'event';
                eventDiv.innerText = evento.nombre;
                dayCell.appendChild(eventDiv);
            });
        }

        calendar.appendChild(dayCell);
    }
}

document.getElementById('prevMonth').onclick = () => {
    currentMonth--;
    if (currentMonth < 0) {
        currentMonth = 11;
        currentYear--;
    }
    renderCalendar();
};

document.getElementById('nextMonth').onclick = () => {
    currentMonth++;
    if (currentMonth > 11) {
        currentMonth = 0;
        currentYear++;
    }
    renderCalendar();
};

renderCalendar();
