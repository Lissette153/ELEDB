        const calendarDays = document.getElementById('calendar-days');
        const eventInfo = document.getElementById('event-info');
        const monthYear = document.querySelector('.month-year');
        let currentDate = new Date();
    
        function renderWeek(date) {
            const startOfWeek = new Date(date);
            startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay() + 1);
            calendarDays.innerHTML = '';
    
            for (let i = 0; i < 7; i++) {
                const day = new Date(startOfWeek);
                day.setDate(startOfWeek.getDate() + i);
                const dayName = day.toLocaleDateString('es-ES', { weekday: 'long' });
                const dayNumber = day.getDate().toString().padStart(2, '0');
                
                const dayElement = document.createElement('div');
                dayElement.classList.add('day');
                dayElement.innerHTML = `${dayName.charAt(0).toUpperCase() + dayName.slice(1)}<br><span class="date">${dayNumber}</span>`;
                
                const dateElement = document.createElement('span');
                dateElement.classList.add('date');
                if (day.toDateString() === today.toDateString()) {
                    dateElement.classList.add('current-day'); // Añadir la clase si es el día actual
                }
                dateElement.textContent = dayNumber;
                dayElement.appendChild(dateElement);
                calendarDays.appendChild(dayElement);
            }
        
            monthYear.textContent = date.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' });
            eventInfo.innerHTML = `<p>${startOfWeek.toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}</p><p>No tienes eventos para hoy.</p>`;
        
            }
    
            monthYear.textContent = date.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' });
            eventInfo.innerHTML = `<p>${startOfWeek.toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}</p><p>No tienes eventos para hoy.</p>`;
    
        document.getElementById('prev-week').addEventListener('click', () => {
            currentDate.setDate(currentDate.getDate() - 7);
            renderWeek(currentDate);
        });
    
        document.getElementById('next-week').addEventListener('click', () => {
            currentDate.setDate(currentDate.getDate() + 7);
            renderWeek(currentDate);
        });
    
        renderWeek(currentDate);
