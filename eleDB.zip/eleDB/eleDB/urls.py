from django.contrib import admin
from django.urls import path
from eleApp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('index',views.index),
    path('modificar_evento/', views.modificar_evento),
    path('visualizar_evento/', views.visualizar_evento,  name='visualizar_evento'),
    path('modificar_finanza/', views.modificar_finanza, name='modificar_finanza')
]
