function validarNombre() {
    const nombre = document.getElementById('nombreFor').value;
    const mensajesError = document.querySelectorAll('.invalid-feedback-nombre');


    mensajesError.forEach(mensaje => mensaje.style.display = 'none');

    if (nombre.trim() === '') {
        mensajesError[0].style.display = 'block'; 
        return false;
    }

    if (nombre.length < 10) {
        mensajesError[0].style.display = 'block'; 
        return false;
    }

    // Validación de caracteres
    if (!/^[a-zA-Z\s]+$/.test(nombre)) {
        mensajesError[1].style.display = 'block'; 
        return false;
    }

    // Validación de longitud máxima
    if (nombre.length > 50) {
        mensajesError[2].style.display = 'block'; 
        return false;
    }

    return true; 
}

/* -------------------------- TIPO --------------------------- */
function validarTipo(){
    const tipo = document.getElementById('tipo_evento').value;
    const mensajesError = document.querySelectorAll('.invalid-feedback-tipo');

    mensajesError.forEach(mensaje => mensaje.style.display = 'none');

    if (tipo.trim() === '') {
        mensajesError[0].style.display = 'block'; 
        return false;
    }

    return true; 
}


/* ------------------FECHA----------------------------- */
function validarFecha() {
    const fecha = document.getElementById('fecha').value;
    const mensajesError = document.querySelectorAll('.invalid-feedback-fecha');


    mensajesError.forEach(mensaje => mensaje.style.display = 'none');

    if (fecha.trim() === '') {
        mensajesError[0].style.display = 'block'; 
        return false;
    }

    const regexFecha = /^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-(\d{4})$/;

    // Validación del formato
    if (!regexFecha.test(fechaInput)) {
        mensajesError[0].style.display = 'block'; 
        return false;
    }
    
    return true; 
}


/* ------------------------------FECHA ----------------------------------------- */
function validarMonto() {
    const montoInput = document.getElementById('monto').value;
    const mensajesError = document.querySelectorAll('.invalid-feedback-monto');

    mensajesError.forEach(mensaje => mensaje.style.display = 'none');

    const monto = parseFloat(montoInput); 

    if (isNaN(monto) || monto <= 0) {
        mensajesError[0].style.display = 'block';
        return false;
    }

    return true; 
}

/* -------------------------- DIRECCION ---------------------------------- */

function validarDireccion() {
    const direccion = document.getElementById('direccion').value;
    const mensajesError = document.querySelectorAll('.invalid-feedback-direccion');


    mensajesError.forEach(mensaje => mensaje.style.display = 'none');

    if (direccion.trim() === '') {
        mensajesError[0].style.display = 'block'; 
        return false;
    }

    if (direccion.length < 10) {
        mensajesError[0].style.display = 'block'; 
        return false;
    }

    // Validación de caracteres
    if (!/^[a-zA-Z\s]+$/.test(direccion)) {
        mensajesError[1].style.display = 'block'; 
        return false;
    }


    if (direccion.length > 50) {
        mensajesError[2].style.display = 'block'; 
        return false;
    }

    return true; 
}

/*---------------------------------EQUIPOS----------------------------------------- */
function validarEquipos() {
    const equipos = document.getElementById('equipos').value;
    const mensajesError = document.querySelectorAll('.invalid-feedback-equipos');


    mensajesError.forEach(mensaje => mensaje.style.display = 'none');

    if (equipos.trim() === '') {
        mensajesError[0].style.display = 'block'; 
        return false;
    }

    if (equipos.length < 10) {
        mensajesError[0].style.display = 'block'; 
        return false;
    }

    // Validación de caracteres
    if (!/^[a-zA-Z\s]+$/.test(equipos)) {
        mensajesError[1].style.display = 'block'; 
        return false;
    }


    if (equipos.length > 100) {
        mensajesError[2].style.display = 'block'; 
        return false;
    }

    return true; 
}




function validarFormulario() {
    const esNombreValido = validarNombre(); 
    const esFechaValida = validarFecha(); 
    const esMontoValido = validarMonto();
    const esTipoValido = validarTipo();
    const estEquipoValido = validarEquipos();
    const estDireccionValido = validarDireccion();
    return esNombreValido && esFechaValida && esMontoValido && esTipoValido && estEquipoValido && estDireccionValido;
}
